Este módulo depende do:

- l10n_br_base
- account_payment_order
- account_due_list
- account_cancel
