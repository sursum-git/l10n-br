from . import test_amount_to_text
from . import test_valid_createid
from . import test_base_onchange
from . import test_other_ie
from . import test_valid_pix
from . import test_partner_bank
