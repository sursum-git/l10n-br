This module does not need any configuration.
