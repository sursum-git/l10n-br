- Existe a possibilidade de criar uma Nota Fiscal com múltiplos
  Modos/Meio de Pagamentos RFC
  <https://github.com/OCA/l10n-brazil/issues/1850>
