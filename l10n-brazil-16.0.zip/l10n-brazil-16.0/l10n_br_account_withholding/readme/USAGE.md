Siga estes passos para utilizar a geração de faturas de retenção de impostos no Odoo:

1. **Criando uma Fatura de Compra:** Ao criar uma fatura de compra, aplique o imposto retido nas linhas necessárias.

2. **Confirmação da Fatura:** Ao confirmar a fatura de compra, o módulo gera automaticamente as faturas de retenção de impostos.

3. **Definir uma Prefeitura para o ISSQN:** Ao incluir um imposto de retenção e informar a cidade correspondente para o ISSQN, o módulo busca automaticamente o parceiro marcado como Prefeitura para essa cidade. Caso não o encontre, ele retorna o parceiro padrão definido no Grupo de Impostos.